from __future__ import annotations

from typing import TYPE_CHECKING

from ._util import encode_path_segment
from ._util import encode_schoolyear as _enc

if TYPE_CHECKING:
    from .client import AusleiheClient


class SchoolyearsAPI:
    """Schuljahres- und Bücherlisten-Endpunkte. Helfer-zugänglich."""

    def __init__(self, client: AusleiheClient) -> None:
        self._client = client

    def get_current(self) -> dict:
        """Aktuelles Schuljahr. ID ist String wie '2025/2026'."""
        return self._client.get("/schoolyears/current")

    def get_by_id(self, schoolyear_id: str) -> dict:
        """Einzelnes Schuljahr mit Booklists[]. ID z.B. '2025/2026'."""
        return self._client.get(f"/schoolyears/{_enc(schoolyear_id)}")

    def get_booklists(self, schoolyear_id: str) -> list[dict]:
        """Alle Bücherlisten eines Schuljahrs. ID z.B. '2025/2026'."""
        return self._client.get(f"/schoolyears/{_enc(schoolyear_id)}/booklists/")

    def get_booklist(self, schoolyear_id: str, booklist_id: int) -> dict:
        """Einzelne Bücherliste mit sections[]->options[]->items[]. ID z.B. '2025/2026'."""
        return self._client.get(
            f"/schoolyears/{_enc(schoolyear_id)}/booklists/{encode_path_segment(booklist_id)}"
        )
